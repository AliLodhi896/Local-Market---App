export default {
  backgroundColor: '#FE724C',
  secondaryColor: '#fff',
  primary: '#FE724C',
  btnPress: '#E86845',
  primaryText: '#404040',
  secondaryText: 'grey',
  green: '#029094',
  
};
